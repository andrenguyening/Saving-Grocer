from flask import Flask, render_template, request, url_for, redirect
from stringgetter import *
app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/result", methods=["GET","POST"])
def result():
    if request.method== 'POST':
        searchitem=str(request.form['grocery_item'])
        zipcode=str(request.form['zip_code'])
        displaystring=gettingstring(searchitem,zipcode)
        return render_template("result.html",message=displaystring)
    else:
        return render_template("index.html")


if __name__ == "__main__":
    app.run(debug=True)