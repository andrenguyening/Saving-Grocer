from bot import *

def gettingstring(searchitem, zipcodestring):
#main
    # searchitem=input("What grocery item are you looking for? ")
    # zipcodestring=input("What is your zip code? ")
    wholefoodsprice=wholefoodsbot(searchitem, zipcodestring)
    print("Whole Foods: ",wholefoodsprice)
    targetprice=targetbot(searchitem)
    print("Target: ",targetprice)
    gianteagleprice=gianteaglebot(searchitem)
    print("Giant Eagle: ",gianteagleprice)

    #compare prices
    sameprice=-1
    if wholefoodsprice<targetprice:
        firstprice=wholefoodsprice
    elif targetprice<wholefoodsprice:
        firstprice=targetprice
    elif targetprice==wholefoodsprice:
        sameprice=wholefoodsprice
        firstprice=sameprice

    #is first price cheaper at firstprice location or giant eagle
    returnstring=""
    if firstprice<gianteagleprice and firstprice == sameprice:
        returnstring="The price at Whole Foods and Target are the same!\nBuy "+str(searchitem)+" at Whole Foods or Target!"
    elif firstprice<gianteagleprice and firstprice == wholefoodsprice:
        returnstring="Whole Foods has the cheapest price!\nBuy "+str(searchitem)+ " at Whole Foods!"
    elif firstprice<gianteagleprice and firstprice == targetprice:
        returnstring="Target has the cheapest price!\nBuy "+str(searchitem)+ " at Target!"
    elif firstprice>gianteagleprice:
        returnstring="Giant Eagle has the cheapest price!\nBuy "+str(searchitem)+ " at Giant Eagle!"
    elif firstprice==gianteagleprice and firstprice == sameprice:
        returnstring="Prices are the same at all three stores!"
    else:
        returnstring="Error!"
    return returnstring