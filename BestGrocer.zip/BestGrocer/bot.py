from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

def wholefoodsbot(searchitem, zipcodestring):
    #headless
    options = webdriver.ChromeOptions()
    user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.109 Safari/537.36"
    options.headless = True
    options.add_argument(f'user-agent={user_agent}')
    options.add_argument("--window-size=1920,1080")
    options.add_argument('--ignore-certificate-errors')
    options.add_argument('--allow-running-insecure-content')
    options.add_argument("--disable-extensions")
    options.add_argument("--proxy-server='direct://'")
    options.add_argument("--proxy-bypass-list=*")
    options.add_argument("--start-maximized")
    options.add_argument('--disable-gpu')
    options.add_argument('--disable-dev-shm-usage')
    options.add_argument('--no-sandbox')
    #for users testing: copy chromedriver path and replace PATH with chromerdriver filepath
    PATH = "/Users/andre/Downloads/BestGrocer/chrome/chromedriver"
    driver = webdriver.Chrome(PATH, options=options)

    #Searching Whole Foods using Whole Foods Bot
    
    #This gets browser to whole foods' website
    driver.get("https://www.wholefoodsmarket.com/")
    search = driver.find_element_by_name("product-search")
    search.send_keys(searchitem)
    search.send_keys(Keys.RETURN)
    
    #selecting closest store location
    wait = WebDriverWait(driver, 3)
    zipcode=wait.until(EC.presence_of_element_located((By.ID,"pie-store-finder-modal-search-field")))
    zipcode.send_keys(zipcodestring)
    wait = WebDriverWait(driver, 3)
    closeststore = wait.until(EC.presence_of_element_located((By.CLASS_NAME,"wfm-search-bar--list_item")))
    closeststore.click()

    #getting price
    wait = WebDriverWait(driver,3)
    stringprice = wait.until(EC.presence_of_element_located((By.CLASS_NAME,"regular_price"))).text

    #converting string price to int
    if stringprice[-1]=='¢':
        stringprice=stringprice[:-1]
        price = float(stringprice)/100
    elif stringprice[-3:] == '/lb':
        stringprice=stringprice[1:-3]
        price=float(stringprice)
    else:
        stringprice=stringprice[1:]
        price=float(stringprice)
    return price

def targetbot(searchitem):
    #headless
    options = webdriver.ChromeOptions()
    user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.109 Safari/537.36"
    options.headless = True
    options.add_argument(f'user-agent={user_agent}')
    options.add_argument("--window-size=1920,1080")
    options.add_argument('--ignore-certificate-errors')
    options.add_argument('--allow-running-insecure-content')
    options.add_argument("--disable-extensions")
    options.add_argument("--proxy-server='direct://'")
    options.add_argument("--proxy-bypass-list=*")
    options.add_argument("--start-maximized")
    options.add_argument('--disable-gpu')
    options.add_argument('--disable-dev-shm-usage')
    options.add_argument('--no-sandbox')

    PATH = "/Users/andre/Downloads/chromedriver"
    driver = webdriver.Chrome(PATH,options=options)
    driver.get("https://www.target.com/")
    search = driver.find_element_by_id("search")
    search.send_keys(searchitem)
    search.send_keys(Keys.RETURN)
    wait=WebDriverWait(driver, 7)
    stringprice = wait.until(EC.presence_of_element_located((By.XPATH,'//*[@id="pageBodyContainer"]/div[1]/div/div[4]/div/div/div[2]/div/section/div/div[1]/div/div/div[2]/div/div/div[2]/div/div/div/span'))).text
    stringprice=stringprice[1:]
    price=float(stringprice)
    return price

def gianteaglebot(searchitem):
    #headless
    options=webdriver.ChromeOptions()
    user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.109 Safari/537.36"
    options.headless = True
    options.add_argument(f'user-agent={user_agent}')
    options.add_argument("--window-size=1920,1080")
    options.add_argument('--ignore-certificate-errors')
    options.add_argument('--allow-running-insecure-content')
    options.add_argument("--disable-extensions")
    options.add_argument("--proxy-server='direct://'")
    options.add_argument("--proxy-bypass-list=*")
    options.add_argument("--start-maximized")
    options.add_argument('--disable-gpu')
    options.add_argument('--disable-dev-shm-usage')
    options.add_argument('--no-sandbox')
    options.add_argument("--disable-geolocation")

    PATH = "/Users/andre/Downloads/chromedriver"
    driver = webdriver.Chrome(PATH, options=options)
    driver.get("https://www.gianteagle.com/")

    #confirm location
    wait = WebDriverWait(driver, 5)
    location = wait.until(EC.presence_of_element_located((By.XPATH,'//*[@id="navHeaderStoreModal"]/div/div[3]/div[1]/div/button')))
    location.click()
    time.sleep(3)

    #search process
    search = driver.find_element_by_name("search")
    wait=WebDriverWait(driver,5)
    search.send_keys(Keys.RETURN)
    wait=WebDriverWait(driver, 5)
    secondsearch = wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="root"]/div/div/div[1]/div/div[1]/div[1]/div[2]/div[1]/div/div/form/div[2]/input')))
    secondsearch.send_keys(searchitem)
    secondsearch.send_keys(Keys.RETURN)
    time.sleep(5)

    #getting price
    stringprice = wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="content"]/div/div/div/div/div[1]/div/div/div[2]/div/div/div[2]/div/a/span/span[1]/span'))).text
    stringprice = stringprice[1:]
    price=float(stringprice)
    return price



